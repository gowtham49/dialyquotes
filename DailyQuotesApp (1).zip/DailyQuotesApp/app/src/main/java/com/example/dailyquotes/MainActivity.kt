package com.example.dailyquotes

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var quoteText: TextView
    private lateinit var newQuoteButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        quoteText = findViewById(R.id.quoteText)
        newQuoteButton = findViewById(R.id.newQuoteButton)

        quoteText.text = Quotes.getRandomQuote()

        newQuoteButton.setOnClickListener {
            quoteText.text = Quotes.getRandomQuote()
        }
    }
}
