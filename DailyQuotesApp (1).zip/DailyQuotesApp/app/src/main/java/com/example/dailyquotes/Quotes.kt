package com.example.dailyquotes

object Quotes {
    private val quotes = listOf(
        "Believe you can and you're halfway there.",
        "Success is not final, failure is not fatal: It is the courage to continue that counts.",
        "Don’t watch the clock; do what it does. Keep going.",
        "The harder you work for something, the greater you’ll feel when you achieve it.",
        "Dream bigger. Do bigger.",
        "Don’t stop when you’re tired. Stop when you’re done."
    )

    fun getRandomQuote(): String {
        return quotes.random()
    }
}
